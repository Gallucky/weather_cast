# weather_cast
A weather app that fetches live temperature and details for any city via API. Referenced by the portfolio project.
